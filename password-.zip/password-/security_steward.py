# -*- coding: utf-8 -*-
"""
Created on Mon May 31 22:32:30 2021

@author: pub
"""


import numpy as np
import math
import time
import random 
import pandas as pd
import tkinter as tk
from PIL import Image,ImageTk
import os



dictionary={"1":1,"2":2,"3":3,"4":4,"5":5,"6":6,"7":7,"8":8,"9":9,"0":0,"A":10,"B":11,"C":12,
           "D":13,"E":14,"F":15,"G":16,"H":17,"I":18,"J":19,"K":20,"L":21,"M":22,"N":23,"O":24,
            "P":25,"Q":26,"R":27,"S":28,"T":29,"U":30,"V":31,"W":32,"X":33,"Y":34,"Z":35,"a":36,
            "b":37,"c":38,"d":39,"e":40,"f":41,"g":42,"h":43,"i":44,"j":45,"k":46,"l":47,"m":48,
            "n":49,"o":50,"p":51,"q":52,"r":53,"s":54,"t":55,"u":56,"v":57,"w":58,"x":59,"y":60,
            "z":61,"~":62,"!":63,"@":64,"#":65,"$":66,"%":67,"^":68,"&":69,"*":70,"(":71,")":72,
            "_":73,"-":74,"=":75,"+":76," ":77,"[":78,"]":79,"{":80,"}":81,"\\":82,"|":83,";":84,
           ":":85,"'":86,"<":87}
div=[">",",",".","?","/"]
char_dic=["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S",
         "T","U","V","W","X","Y","Z","a","b","c","d","e","f","g","h","i","j","k","l","m",
         "n","o","p","q","r","s","t","u","v","w","x","y","z","0","1","2","3","4","5","6",
         "7","8","9"]
num_dic=["1","2","3","4","5"]
virus_dic={}
length=len(char_dic)
for index in range(length):
    for items in num_dic:
        for index1 in range(length):
            char=char_dic[index]+items+char_dic[index1]
            length_num=random.randint(5,11)
            virus_dic[char]=str(random.randint(10**(length_num-1),10**length_num-1))

virus_dic["t1i"]='907061761'
virus_dic["a1i"]='264402106'
virus_dic["n1i"]='29095'
virus_dic["g1i"]='7472222'
virus_dic["x1i"]='4805267810'
virus_dic["i1i"]='6343237'
virus_dic["n2i"]='243785748'
virus_dic["g2i"]='656890'
virus_dic["w1i"]='5725745'
virus_dic["e1i"]='78383'
virus_dic["i2i"]='2480679161'



def fast_encode(x,e,n):
    result=1
    while True:
        if e==1:
            result=(result*(x%n))%n
            break
        if e%2==1:
            result=(result*(x%n))%n
            e=e-1
        elif e%2==0:
            x=(x**2)%n
            e=e//2
    return(result)

def recover_key(password):
    order_list=char_count(password)
    char=''
    for index in range(len(order_list)):
        char=char+virus_dic[password[index]+order_list[index]+password[-1]]
    char_length=len(char)
    password_1=int(char[0:char_length//2])
    password_2=int(char[char_length//2:char_length])
    return((password_1-1)*(password_2-1))

def fast_decode(code,e,n,password):
    phi_n=recover_key(password)
    k=1
    while True:
        x=(k*phi_n+1)%e
        if x==0:
            break
        k=k+1
    d=(k*phi_n+1)//e
    word=fast_encode(code,d,n)
    return (word)

def string_code(code):
    num_list=[dictionary[code[index]] for index in range(len(code))]
    return(num_list)

def find_key(value):
    for string,num in dictionary.items():
        if value==num:
            result=string
        if value>87:
            result=True
    return(result)      

def password_part(pass_length,length):
    while True:
        part_length=[random.randint(5,11) for index in range(pass_length)]
        if sum(part_length)==length:
            break
    return(part_length)

def char_count(word):
    length=len(word)
    count_list=['1' for index in range(length)]
    for index in range(1,length):
        count=1
        for index1 in range(index):
            if word[index1]==word[index]:
                count=count+1
        count_list[index]=str(count)
    return(count_list)

def trans_char(num):
    string=str(num)
    length=len(string)
    result=''
    for index in range(int(length/2)):
        var_string=string[2*index:2*index+2]
        var_num=int(var_string)
        if var_num<10 or var_num>87:
            coded_string=var_string
        else:
            coded_string=find_key(var_num)
        result=result+coded_string
    if length%2==1:
        result=result+string[-1]
    return(result)

def code_storage(account,password):
    global safe_guarder
    account_list=safe_guarder['Account']
    account_list=np.append(account_list,account)
    password_list=safe_guarder['Password']
    number_password=string_code(password)
    coded_password=[trans_char(fast_encode(number_password[i],72869,392188505005195017497151006216795254000413988942237176065905728417534125375393528143)) for i in range(len(number_password))]
    add_pass=''
    for item in coded_password:
        add_pass=add_pass+item+div[random.randint(0,4)]
    password_list=np.append(password_list,add_pass)
    safe_guarder_data={'Account':account_list,'Password':password_list}
    safe_guarder=pd.DataFrame(safe_guarder_data)
    
def belong(ele,list1):
    length=len(list1)
    count=0
    for items in list1:
        if ele==items:
            break
        else:
            count=count+1
    if count<length:
            return(True)
    else:
        return(False)     

def trans_decode(code,password):
    string_list=[]
    index0=0
    for index in range(len(code)):
        if belong(code[index],div):
            string_list=np.append(string_list,code[index0:index])
            index0=index+1
    string_length=len(string_list)
    num_list=[0 for i in range(string_length)]
    for index1 in range(string_length):
        length=len(string_list[index1])
        num_ele=''
        items=string_list[index1]
        for index in range(length):
            num_ele=num_ele+str(dictionary[items[index]])
        num_ele1=int(num_ele)
        num_list[index1]=num_ele1
    password_items=''
    for items in num_list:
        if fast_decode(items,72869,392188505005195017497151006216795254000413988942237176065905728417534125375393528143,password)>87:
            password_items='Please enter the correct password.'
            break
        else:
            password_items=password_items+find_key(fast_decode(items,72869,392188505005195017497151006216795254000413988942237176065905728417534125375393528143,password))
    return(password_items)

def change_password(origin_pass,new_pass):
    origin_length=len(origin_pass)
    char_order=char_count(origin_pass)
    origin_char=''
    for index in range(origin_length):
        origin_char=origin_char+virus_dic[origin_pass[index]+char_order[index]+origin_pass[-1]]
        rand_num=random.randint(5,11)
        virus_dic[origin_pass[index]+char_order[index]+origin_pass[-1]]=str(random.randint(10**(rand_num-1),10**rand_num-1))
        length_1=len(origin_char)
    if int(origin_char[0:length_1//2])*int(origin_char[(length_1//2):length_1])==392188505005195017497151006216795254000413988942237176065905728417534125375393528143:
        new_length=len(new_pass)
        part_list=password_part(new_length,length_1)
        new_char_order=char_count(new_pass)
        prime_part=["0" for index in range(len(part_list))]
        tot_num=0
        for index in range(len(prime_part)):
            prime_part[index]=origin_char[tot_num:tot_num+part_list[index]]
            tot_num=tot_num+part_list[index]
        key_list=[new_pass[index]+new_char_order[index]+new_pass[-1] for index in range(len(part_list))]
        for index in range(len(key_list)):
            virus_dic[key_list[index]]=prime_part[index]
    else:
        print("Please enter the right pass word")








def next_page(frame_name):
    frame_name.tkraise()
    
def complete_input(button):
    global Account_list
    global Password_list
    global data_file
    children_widgets=home_frame.winfo_children()
    content_list=[]
    for widget in children_widgets:
        if widget.winfo_class()=='Entry':
            content_list=np.append(content_list,widget.get())
    content_length=len(content_list)
    Account_list=[content_list[index] for index in range(0,content_length,2)]
    Password_list=[]
    for index in range(1,content_length,2):
        if len(content_list[index])<50:
            number_password=string_code(content_list[index])
            coded_password=[trans_char(fast_encode(number_password[i],72869,392188505005195017497151006216795254000413988942237176065905728417534125375393528143)) for i in range(len(number_password))]
            add_pass=''
            for item in coded_password:
                add_pass=add_pass+item+div[random.randint(0,4)]
            Password_list=np.append(Password_list,add_pass)
        else:
            Password_list=np.append(Password_list,content_list[index])
        

    data={'Account':Account_list,'Password':Password_list}
    data_file=pd.DataFrame(data)
    data_file.to_csv('Safe_Guarder.csv',line_terminator='\n')
    button.place_forget()    
    
    
def add_password():
    global row
    for column_index in range(2):
        password_table=tk.Entry(home_frame,text='')
        relx_var=relx_center+column_index*step_x
        rely_var=rely_center+row*step_y
        password_table.place(relx=relx_var,rely=rely_var)
    complete_button=tk.Button(home_frame,text='complete',command=lambda:complete_input(complete_button))
    complete_button.place(relx=relx_var+step_x,rely=rely_var)
    row=row+1

def login_fun():
    origin_pass=login_entry.get()
    origin_length=len(origin_pass)
    char_order=char_count(origin_pass)
    origin_char=''
    for index in range(origin_length):
        origin_char=origin_char+virus_dic[origin_pass[index]+char_order[index]+origin_pass[-1]]
    length_1=len(origin_char)
    if int(origin_char[0:length_1//2])*int(origin_char[(length_1//2):length_1])==392188505005195017497151006216795254000413988942237176065905728417534125375393528143:
        children_widgets=home_frame.winfo_children()
        entry_index=1
        for widget in children_widgets:
            if widget.winfo_class()=='Entry':
                if entry_index%2==0:
                    entry_content=widget.get()
                    real_pass=trans_decode(entry_content,origin_pass)
                    widget.delete(0,'end')
                    widget.insert(-1,real_pass)
                entry_index=entry_index+1
        home_frame.tkraise()
    

def logoff_fun():
    children_widgets=home_frame.winfo_children()
    entry_index=1
    for widget in children_widgets:
        if widget.winfo_class()=='Entry':
            if entry_index%2==0:
                entry_content=widget.get()
                number_password=string_code(entry_content)
                coded_password=[trans_char(fast_encode(number_password[i],72869,392188505005195017497151006216795254000413988942237176065905728417534125375393528143)) for i in range(len(number_password))]
                add_pass=''
                for item in coded_password:
                    add_pass=add_pass+item+div[random.randint(0,4)]
           
                widget.delete(0,'end')
                widget.insert(-1,add_pass)
            entry_index=entry_index+1
    welcome_frame.tkraise()
    
    
    
Safe_Guard=tk.Tk()
Safe_Guard.title('Security Steward')
Safe_Guard.configure(bg='white')


home_frame=tk.Frame(Safe_Guard)
home_frame.place(x=0,y=0,relwidth=1,relheight=1)

welcome_frame=tk.Frame(Safe_Guard)
welcome_frame.place(x=0,y=0,relwidth=1,relheight=1)


Pic=Image.open('envolop.png').resize((1250,1200))
Background_Pic=ImageTk.PhotoImage(Pic)
Background_label=tk.Label(welcome_frame,image=Background_Pic)
Background_label.place(x=0,y=0,relwidth=1,relheight=1)
Safe_Guard.geometry('1000x700')

login_entry=tk.Entry(welcome_frame,text='',show='*')
login_entry.place(relx=0.43,rely=0.47)

mascot=Image.open('steward.png').resize((100,100))
mascot_Pic=ImageTk.PhotoImage(mascot)
mascot_label=tk.Label(welcome_frame,image=mascot_Pic)
mascot_label.place(relx=0.46,rely=0.17)

login_text=tk.Label(welcome_frame,text='Your security steward',font=('Times New Roman',27,'bold'))
login_text.place(relx=0.35,rely=0.3)

login_button=tk.Button(welcome_frame,text='Log In',font=('Times New Roman',21,'bold'),command=login_fun)
login_button.place(relx=0.45,rely=0.52)


safe_text=tk.Label(welcome_frame,text='Your password is guarded by us',font=('Times New Roman',15,'bold'))
safe_text.place(relx=0.33,rely=0.9)

copyright_label=tk.Label(welcome_frame,text=u"\u00A9" + " 2021  Qianhang Ding & Sivi Tang",font=('Times New Roman',15))
copyright_label.place(relx=0.61,rely=0.9)

add_image=tk.PhotoImage(file='add.png')
add_button=tk.Button(home_frame,image=add_image,command=add_password)
add_button["border"]="0"
add_button.place(relx=0.6,rely=0.05)

add_text=tk.Label(home_frame,text='Create a new account & password', font=('Times New Roman',17))
add_text.place(relx=0.67,rely=0.07)

data_file=pd.read_csv('Safe_Guarder.csv')
Account_list=data_file['Account']
Password_list=data_file['Password']


column=2
row=len(Account_list)
relx_center=0.3
rely_center=0.2
step_x=0.2
step_y=0.04


for row_index in range(row):
    for column_index in range(column):
        text_var=tk.StringVar()
        if column_index==0:
            text_var.set(Account_list[row_index])
        else:
            text_var.set(Password_list[row_index])
        password_table=tk.Entry(home_frame,text=text_var)
        relx_var=relx_center+column_index*step_x
        rely_var=rely_center+row_index*step_y
        password_table.place(relx=relx_var,rely=rely_var)
logoff_button=tk.Button(home_frame, text='Log Off', font=('Times New Roman', 21,'bold'),command=logoff_fun)
logoff_button.place(relx=0.8,rely=0.8)

Safe_Guard.mainloop()


